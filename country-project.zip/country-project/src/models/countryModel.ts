export interface CountryData {
    name: string;
    capital?: string;
    population?: number;
    currencies?:any;
    flag?: string;  
}

export interface Currency {
   name: string;  
}

export interface DropdownData {
 label?: string;
 value?: CountryData;
}