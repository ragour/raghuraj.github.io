export const environment = {
  production: true,
  baseUrl: 'https://restcountries.com/v2/region/'
};
