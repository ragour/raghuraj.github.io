import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { CountryData } from 'src/models/countryModel';
import { State } from '../Store/reducers';

@Component({
  selector: 'app-country-table',
  templateUrl: './country-table.component.html',
  styleUrls: ['./country-table.component.css']
})
export class CountryTableComponent implements OnInit {
  selectedCountry: CountryData | undefined;
  constructor(private store:Store<State>,private changeDetectorRef: ChangeDetectorRef) { }

  ngOnInit(): void {
  this.store.select(state => state.countrylist.countryDetails)
 .subscribe((res: CountryData | undefined)=>{ 
  this.changeDetectorRef.detectChanges();
  this.selectedCountry = res;
  })
}

}
