import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, map, mergeMap,tap } from 'rxjs/operators';
import { of } from 'rxjs';
import { CountryService } from 'src/service/country.service';
import * as CountryActions from '../actions/country.actions';


@Injectable()
export class CountryListEffects {

  constructor(private countryService:CountryService,private actions$: Actions) {}
  loadCountryList$ = createEffect(() =>
  this.actions$.pipe(
    ofType(CountryActions.selRegion),
    tap(() => console.log('effects working$', )),
    mergeMap((action: { region: string; }) =>{
     return this.countryService
        .loadCountry(action.region) 
        .pipe(map((country: any) => CountryActions.loadCountrysSuccess({ country })),
        catchError((error: { error: any; }) => of(CountryActions.loadCountrysFailure(error))),
        
        )
    })
  )
);
}
