import { Injectable } from '@angular/core';

import { environment } from '../environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { CountryData, DropdownData } from '../models/countryModel';
import { map } from 'rxjs/operators';
import { Observable, pipe } from 'rxjs'

@Injectable({
  providedIn: 'root',
})
export class CountryService {
  baseUrl = environment.baseUrl;

  constructor(private http: HttpClient) {}

  loadCountry(region: string): Observable<CountryData[]> {
    console.log('test');

    return this.http.get<CountryData[]>(`${this.baseUrl}/${region}`).pipe(
      map((res: CountryData[]) => {
        return res.map((country) => ({ 
          name: country.name,
          capital: country.capital,
          population: country.population,
          currencies: country.currencies,
          flag: country.flag,
        }));
      })
    );
  }
}
